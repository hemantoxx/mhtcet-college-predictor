import React, { useState } from 'react';

function PredictorForm() {
  const [formData, setFormData] = useState({
    jeeMainRank: '',
    jeeAdvancedRank: '',
    category: '',
    seatPool: '',
    state: '',
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(formData);
    // Add prediction logic here
  };

  return (
    <div className="min-h-screen bg-white py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        {/* Header Section */}
        <div className="text-center mb-10">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
            MHT-CET COLLEGE PREDICTOR
          </h1>
          <p className="text-green-600 font-medium mb-6">No Hidden Charges, 100% Free</p>
          
          <div className="mb-8">
            <p className="text-gray-500 text-sm mb-4">Made in Collaboration with</p>
            <div className="flex justify-center items-center gap-8">
              <p className="font-medium">MHTCET STUDENTS GROUP</p>
              <p className="font-medium"></p>
            </div>
          </div>
          
          <p className="text-gray-600">
            78,850 MHTCET 2025 Aspirants have already predicted their branch and college
          </p>
        </div>

        {/* Form Section */}
        <div className="bg-white shadow-lg rounded-xl p-6 mb-8">
          <form onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
              {/* JEE Main Rank */}
              <div className="flex flex-col">
                <label className="text-sm font-semibold text-gray-700 mb-1">
                  MHTCET-RANK
                </label>
                <input
                  type="text"
                  name="jeeMainRank"
                  onChange={handleChange}
                  placeholder="Enter your Rank"
                  className="border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* JEE Advanced Rank */}
              <div className="flex flex-col">
                <label className="text-sm font-semibold text-gray-700 mb-1">
                  MHT-CET PERCENTILE
                </label>
                <input
                  type="text"
                  name="jeeAdvancedRank"
                  onChange={handleChange}
                  placeholder="Rank (Optional)"
                  className="border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* Category */}
              <div className="flex flex-col">
                <label className="text-sm font-semibold text-gray-700 mb-1">
                  Category <span className="text-red-500">*</span>
                </label>
                <select
                  name="category"
                  onChange={handleChange}
                  required
                  className="border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select Category</option>
                  <option value="GEN">GEN</option>
                  <option value="OBC">OBC</option>
                  <option value="SC">SC</option>
                  <option value="ST">ST</option>
                  <option value="ST">VJ</option>
                  
                </select>
              </div>

              {/* Seat Pool */}
              <div className="flex flex-col">
                <label className="text-sm font-semibold text-gray-700 mb-1">
                  Seat Pool <span className="text-red-500">*</span>
                </label>
                <select
                  name="seatPool"
                  onChange={handleChange}
                  required
                  className="border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select Seat Pool</option>
                  <option value="Gender-Neutral">Gender-Neutral</option>
                  <option value="Female-Only">Female-Only</option>
                </select>
              </div>

              {/* State */}
              <div className="flex flex-col">
                <label className="text-sm font-semibold text-gray-700 mb-1">
                  12th Class Domicile State <span className="text-red-500">*</span>
                </label>
                <select
                  name="state"
                  onChange={handleChange}
                  required
                  className="border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select State</option>
                  <option value="Maharashtra">Maharashtra</option>
                  <option value="Delhi">Delhi</option>
                  <option value="Rajasthan">Rajasthan</option>
                  <option value="Other">Other</option>
                </select>
              </div>
            </div>

            <div className="text-center">
              <button
                type="submit"
                className="bg-blue-600 text-white font-semibold py-3 px-8 rounded-md hover:bg-blue-700 transition-colors"
              >
                Predict
              </button>
            </div>
          </form>
        </div>

        {/* Note Section */}
        <div className="bg-orange-100 text-orange-800 p-4 rounded-lg flex items-start gap-3 mb-10">
          <span className="text-xl">⚡</span>
          <p className="text-sm">
            Fill all the fields above to get better results. Enter category rank if applicable.
          </p>
        </div>

        {/* Product Description */}
        <div className="text-center">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Product</h3>
          <p className="text-gray-600">
            Accurate, AI-Driven Predictions Using Past Data Trends
          </p>
        </div>
      </div>
    </div>
  );
}

export default PredictorForm;