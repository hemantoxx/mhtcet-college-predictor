import PredictorForm from './components/PredictorForm';

function App() {
  return (
    <div className="min-h-screen bg-white text-black flex items-center justify-center p-4">
      <PredictorForm />
    </div>
  );
}

export default App;
